# Phone Pong

Table tennis where your phone is the paddle, played against the computer. The game runs on a host screen (laptop or TV browser); your phone joins by scanning a QR code and swings to hit.

## Run it

You need Node 18+ on the computer that will show the game.

```
npm install
npm start
```

1. Open **http://localhost:3000** on the computer / TV. A lobby with a QR code and a 4-letter room code appears.
2. On each phone (same Wi-Fi), scan the QR code. The first visit shows a certificate warning because the server uses a self-signed HTTPS certificate: tap **Advanced, then Proceed**. HTTPS is required for phones to allow motion sensors.
3. Tap **Join game**. On iPhone, tap **Allow** when asked for motion access.
4. The match starts as soon as your phone has joined. First to 7 (win by 2); a new match starts automatically a few seconds after one ends.

The computer is always your opponent. Press **1 / 2 / 3** on the host screen for easy, medium (default) or hard, and **F** for fullscreen.

No phone handy? Press **Z**, **X** or **C** on the host screen to join from the keyboard (the first press joins, after that Z, X, C are a soft, medium or hard swing).

## The view

The game is first person: the camera is at your end of the table, looking down it, with your right hand holding the paddle in front of you and your left hand resting at the bottom of the screen (it lifts when it is your serve). Your paddle slides to follow the incoming ball and swings forward when you hit. The other player stands at the far end with their paddle.


The camera position and angle are `EYE` in `host.html` (`back`, `up`, `pitch`), and the hand drawing is in `drawRightHand` and `drawLeftHand`.

## How to play

- The server's turn comes first: **swing to serve**.
- Wait for the ball to bounce on your side, then **swing as it reaches your end of the table**. Timing is the skill: a swing right at your end line is clean, an early or late one can go into the net or land short, and too early or too late is a miss.
- **Swing harder for a deeper, faster shot.** A full-power shot goes long, so find the middle.
- **Tilt the phone left or right to aim.** "Center aim" on the controller recalibrates what counts as straight.
- If motion is not available, swipe up on the pad: speed is power, sideways position is aim.

## Files

| File | What it does |
|---|---|
| `server.js` | Serves the pages and relays messages between host and phones. Rooms, reconnects, HTTPS. |
| `public/host.html` | The big screen: lobby, first-person 3D view with your hands, sound, scoreboard. |
| `public/controller.html` | The phone: join form, swing detection, swipe pad, haptics. |
| `public/game.js` | All rules and physics, no browser code. Shared by the host and the tests. |
| `test/sim.js` | `npm run sim`: bots play full matches and the rules are checked. |

## Tuning

- **Swing feel** is `SW` near the top of the motion section in `controller.html`. `START` is how hard a movement must be to count as a swing, `MAX` is the acceleration that counts as full power. If swings feel too hard or too easy to trigger, change these first.
- **Timing window** is `HIT_ZONE`, `PAST_END` and `SWEET_WIDTH` in `game.js`. Raise them to make the game more forgiving.
- **Ball speed and bounce** are `G`, `REST` and `SKID` in `game.js`.

## What has been tested

- The rules and physics: `npm run sim` plays hundreds of points with bots and checks scoring, serve rotation, swing rules, reconnect behaviour, and that timing and power matter.
- The host and controller pages load and render without errors in a desktop browser.

## Not yet tested

- The relay server end to end. It was written and syntax-checked but not run with real clients, because the `ws` package could not be installed in the environment it was built in.
- Swing detection on real phones. The thresholds are educated guesses and will likely need a few rounds of tuning on your devices.
- Different phones and browsers (iOS Safari, Android Chrome) for the motion permission flow.

## Next ideas

- Spin: use the phone's tilt at the moment of the swing.
- Two phone players: the game already supports it (split-screen first-person view); it is switched off. Set `slots` in `server.js` back to two entries and remove the `setCpu('medium')` call near the bottom of `host.html`.
- A best-of-3 match screen.
- A second mini-game on the same server (darts: aim with the gyro, flick to throw).
