/* Phone Pong: game logic (no DOM). Runs in the browser (window.PongGame) and in Node (require).
 *
 * Table coordinates: x runs along the table (0 = player 0's end, 1 = player 1's end),
 * y runs across it (0 = far edge, 1 = near edge), z is height above the table.
 * Distances are in table lengths, time is in seconds.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PongGame = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const CFG = {
    WIN_SCORE: 7,      // first to this, and 2 clear
    G: 1.6,            // gravity
    NET_X: 0.5,
    NET_H: 0.045,      // net height
    SERVE_Z: 0.07,     // ball height when served
    HIT_ZONE: 0.3,     // ball can be hit once it is this close to your end line
    PAST_END: 0.2,     // ...and until it is this far past it
    SWEET_WIDTH: 0.22, // distance from your end line where timing quality drops to 0
    REST: 0.75,        // bounce energy kept
    SKID: 0.8,         // horizontal speed kept after a bounce
    POINT_PAUSE: 1.8,  // seconds between points
    OVER_PAUSE: 8,     // seconds before an automatic rematch
    STEP: 1 / 240      // physics step
  };

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  function gauss(rng) {
    let u = 0, v = 0;
    while (u === 0) u = rng();
    while (v === 0) v = rng();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  function createGame(opts) {
    opts = opts || {};
    const rng = opts.rng || Math.random;
    const emit = opts.onEvent || function () {};
    const cfg = Object.assign({}, CFG, opts.cfg || {});

    const state = {
      phase: 'waiting', // waiting | serve | rally | point | over
      score: [0, 0],
      server: 0,
      firstServer: 0,
      matches: 0,
      inMatch: false,
      timer: 0,
      rallyId: 0,
      rally: 0,
      connected: [false, false],
      lastWinner: -1,
      lastReason: '',
      ball: { x: 0, y: 0.5, z: cfg.SERVE_Z, vx: 0, vy: 0, vz: 0, bounces: 0, hitter: -1 }
    };

    function bothConnected() { return state.connected[0] && state.connected[1]; }

    function setConnected(player, value) {
      state.connected[player] = !!value;
      if (!bothConnected()) {
        if (state.phase !== 'waiting') {
          state.phase = 'waiting';
          state.timer = 0;
          emit('waiting', {});
        }
      } else if (state.phase === 'waiting') {
        if (state.inMatch) beginServe(); else startMatch();
      }
    }

    function startMatch() {
      state.score = [0, 0];
      state.firstServer = state.matches % 2;
      state.matches++;
      state.inMatch = true;
      state.lastWinner = -1;
      emit('start', {});
      beginServe();
    }

    function beginServe() {
      const total = state.score[0] + state.score[1];
      state.server = (state.firstServer + Math.floor(total / 2)) % 2;
      state.phase = 'serve';
      state.timer = 0;
      state.rally = 0;
      const b = state.ball;
      b.x = state.server === 0 ? 0 : 1;
      b.y = 0.35 + rng() * 0.3;
      b.z = cfg.SERVE_Z;
      b.vx = b.vy = b.vz = 0;
      b.bounces = 0;
      b.hitter = -1;
      emit('serve', { server: state.server, score: state.score.slice() });
    }

    // Send the ball back towards the other end. power 0..1 sets how deep and fast
    // it goes, aim -1..1 (left..right from the player's view) sets where across.
    function launch(player, power, aim, quality) {
      const b = state.ball;
      const noise = 1 - quality;
      const p = clamp(power + gauss(rng) * noise * 0.12, 0, 1);
      const a = clamp(aim + gauss(rng) * noise * 0.35, -1, 1);
      const mishit = quality < 0.4 && rng() < (0.4 - quality);
      const dir = player === 0 ? 1 : -1;
      const depth = 0.1 + 0.95 * p;      // 1 = the far end line, so p > ~0.95 goes long
      const T = 1.0 - 0.45 * p;          // time to the first bounce
      const x0 = b.x, y0 = b.y, z0 = Math.max(b.z, 0.03);
      const xl = cfg.NET_X + dir * 0.5 * depth;
      const yl = 0.5 + a * 0.46 * (player === 0 ? 1 : -1);
      b.vx = (xl - x0) / T;
      b.vy = (yl - y0) / T;
      b.vz = (0.5 * cfg.G * T * T - z0) / T;
      if (mishit) b.vz *= 0.4;           // flat shot: into the net or short
      b.z = z0;
      b.bounces = 0;
      b.hitter = player;
      state.phase = 'rally';
      state.timer = 0;
      state.rallyId++;
      state.rally++;
      emit('hit', { player, power: p, aim: a, quality, mishit, rally: state.rally });
    }

    function whiff(player, reason) {
      emit('whiff', { player, reason });
      return { ok: false, reason };
    }

    // A player swung their phone. Returns { ok } (and a reason when it did not count).
    function swing(player, power, aim) {
      power = clamp(+power || 0, 0, 1);
      aim = clamp(+aim || 0, -1, 1);
      const b = state.ball;
      if (state.phase === 'serve') {
        if (player !== state.server) return whiff(player, 'not your serve');
        launch(player, power, aim, 1);
        return { ok: true };
      }
      if (state.phase !== 'rally') return { ok: false, reason: 'not playing' };
      if (player !== 1 - b.hitter) return whiff(player, 'wait for your turn');
      if (b.bounces < 1) return whiff(player, 'too early');
      const u = player === 0 ? b.x : 1 - b.x; // distance in front of your end line (negative = past it)
      if (u > cfg.HIT_ZONE) return whiff(player, 'too early');
      if (u < -cfg.PAST_END) return whiff(player, 'too late');
      const quality = 1 - clamp(Math.abs(u) / cfg.SWEET_WIDTH, 0, 1);
      launch(player, power, aim, quality);
      return { ok: true, quality };
    }

    function awardPoint(winner, reason) {
      state.score[winner]++;
      state.lastWinner = winner;
      state.lastReason = reason;
      const a = state.score[0], c = state.score[1];
      const over = Math.max(a, c) >= cfg.WIN_SCORE && Math.abs(a - c) >= 2;
      state.phase = over ? 'over' : 'point';
      state.timer = 0;
      if (over) state.inMatch = false;
      emit('point', { winner, reason, score: state.score.slice(), over, rally: state.rally });
      if (over) emit('over', { winner, score: state.score.slice() });
    }

    function step(dt) {
      const b = state.ball;
      const px = b.x;
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.vz -= cfg.G * dt;
      b.z += b.vz * dt;

      // The net
      if ((px - cfg.NET_X) * (b.x - cfg.NET_X) < 0 && b.z < cfg.NET_H) {
        return awardPoint(1 - b.hitter, 'net');
      }

      // Table bounce
      if (b.z <= 0 && b.vz < 0) {
        b.z = 0;
        if (b.bounces >= 1) return awardPoint(b.hitter, 'missed'); // second bounce before a return
        const receiver = 1 - b.hitter;
        const onTable = b.x >= 0 && b.x <= 1 && b.y >= 0 && b.y <= 1;
        if (!onTable) return awardPoint(receiver, 'out');
        if ((b.x < cfg.NET_X ? 0 : 1) !== receiver) return awardPoint(receiver, 'short');
        b.bounces = 1;
        b.vz = -b.vz * cfg.REST;
        b.vx *= cfg.SKID;
        b.vy *= cfg.SKID;
        emit('bounce', { x: b.x, y: b.y });
        return;
      }

      // Ball got past the receiver, or flew off before bouncing
      if (b.bounces >= 1 && (b.x < -cfg.PAST_END || b.x > 1 + cfg.PAST_END)) return awardPoint(b.hitter, 'missed');
      if (b.bounces === 0 && (b.x < -0.3 || b.x > 1.3)) return awardPoint(1 - b.hitter, 'out');
      if (state.timer > 20) return awardPoint(b.hitter, 'missed');
    }

    function update(dt) {
      state.timer += dt;
      if (state.phase === 'rally') {
        let rem = dt;
        while (rem > 0 && state.phase === 'rally') {
          const h = Math.min(cfg.STEP, rem);
          step(h);
          rem -= h;
        }
      } else if (state.phase === 'point' && state.timer > cfg.POINT_PAUSE) {
        beginServe();
      } else if (state.phase === 'over' && state.timer > cfg.OVER_PAUSE) {
        if (bothConnected()) startMatch();
        else { state.phase = 'waiting'; state.timer = 0; emit('waiting', {}); }
      }
    }

    return { state, cfg, setConnected, swing, update };
  }

  // A simple computer player, handy for solo testing and for the headless simulation.
  function createBot(game, player, opts) {
    opts = opts || {};
    const rng = opts.rng || Math.random;
    const skill = opts.skill == null ? 0.85 : opts.skill;
    let lastRally = -1, swung = true, swingAt = 0.02, willMiss = false, wait = 0;
    return {
      player,
      update(dt) {
        const s = game.state, b = s.ball;
        if (s.phase === 'serve') {
          if (s.server !== player) return;
          wait += dt;
          if (wait > 1.2) {
            wait = 0;
            game.swing(player, 0.45 + rng() * 0.2, (rng() * 2 - 1) * 0.7);
          }
          return;
        }
        wait = 0;
        if (s.phase !== 'rally') return;
        if (s.rallyId !== lastRally) {
          lastRally = s.rallyId;
          swung = b.hitter === player;
          swingAt = 0.02 + (rng() * 2 - 1) * (0.04 + (1 - skill) * 0.3);
          willMiss = rng() > skill + 0.1;
        }
        if (swung || b.bounces < 1) return;
        const u = player === 0 ? b.x : 1 - b.x;
        if (u <= swingAt) {
          swung = true;
          if (!willMiss) game.swing(player, clamp(0.55 + gauss(rng) * 0.1, 0.1, 1), (rng() * 2 - 1) * 0.8);
        }
      }
    };
  }

  return { CFG, createGame, createBot, clamp };
});
