'use strict';
/*
 * Phone Pong relay server.
 *  - serves the host screen (/) and the phone controller (/play)
 *  - relays messages between one host screen and up to two phones per room
 *
 * Phones only get motion sensor access on a secure origin (HTTPS), so the server
 * also starts an HTTPS listener with a self-signed certificate. The host screen
 * can stay on plain http://localhost; phones use the https:// address in the QR code.
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { WebSocketServer } = require('ws');

let QRCode = null;
try { QRCode = require('qrcode'); } catch (e) { /* optional: the host screen just won't show a QR code */ }
let selfsigned = null;
try { selfsigned = require('selfsigned'); } catch (e) { /* optional: no HTTPS, phones fall back to the swipe pad */ }

const HTTP_PORT = +process.env.PORT || 3000;
const HTTPS_PORT = +process.env.HTTPS_PORT || 3443;
const PUBLIC_DIR = path.join(__dirname, 'public');
const CERT_DIR = path.join(__dirname, '.cert');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.json': 'application/json'
};

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const n of list || []) {
      if ((n.family === 'IPv4' || n.family === 4) && !n.internal) out.push(n.address);
    }
  }
  return out;
}

async function loadCert(ips) {
  if (!selfsigned || process.env.NO_HTTPS) return null;
  try {
    fs.mkdirSync(CERT_DIR, { recursive: true });
    const keyFile = path.join(CERT_DIR, 'key.pem');
    const certFile = path.join(CERT_DIR, 'cert.pem');
    const ipFile = path.join(CERT_DIR, 'ips.json');
    const wanted = JSON.stringify(ips);
    if (fs.existsSync(keyFile) && fs.existsSync(certFile) && fs.existsSync(ipFile) &&
        fs.readFileSync(ipFile, 'utf8') === wanted) {
      return { key: fs.readFileSync(keyFile), cert: fs.readFileSync(certFile) };
    }
    const altNames = [
      { type: 2, value: 'localhost' },
      { type: 7, ip: '127.0.0.1' },
      ...ips.map((ip) => ({ type: 7, ip }))
    ];
    const pems = await Promise.resolve(selfsigned.generate(
      [{ name: 'commonName', value: 'phone-pong.local' }],
      { days: 365, keySize: 2048, algorithm: 'sha256', extensions: [{ name: 'subjectAltName', altNames }] }
    ));
    fs.writeFileSync(keyFile, pems.private);
    fs.writeFileSync(certFile, pems.cert);
    fs.writeFileSync(ipFile, wanted);
    return { key: pems.private, cert: pems.cert };
  } catch (e) {
    console.warn('Could not set up HTTPS (' + e.message + '). Phones will use the swipe pad instead of motion.');
    return null;
  }
}

const info = { ips: [], httpPort: HTTP_PORT, httpsPort: null };

function serveFile(res, urlPath) {
  const rel = urlPath === '/' ? '/host.html' : urlPath === '/play' ? '/controller.html' : urlPath;
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    });
    res.end(data);
  });
}

async function handler(req, res) {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname === '/info') {
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify(info));
    }
    if (url.pathname === '/qr') {
      const text = url.searchParams.get('text') || '';
      if (!QRCode || !text || text.length > 300) { res.writeHead(404); return res.end(); }
      const svg = await QRCode.toString(text, { type: 'svg', margin: 1, color: { dark: '#0b1020', light: '#ffffff' } });
      res.writeHead(200, { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'no-store' });
      return res.end(svg);
    }
    serveFile(res, decodeURIComponent(url.pathname));
  } catch (e) {
    res.writeHead(500);
    res.end('Server error');
  }
}

// ---------------------------------------------------------------- rooms

const rooms = new Map(); // code -> { code, host, slots: [{ ws, token, name } x2], cleanup }
const wss = new WebSocketServer({ noServer: true });

function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function newCode() {
  const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  let code;
  do {
    code = '';
    for (let i = 0; i < 4; i++) code += letters[Math.floor(Math.random() * letters.length)];
  } while (rooms.has(code));
  return code;
}

function playersOf(room) {
  return room.slots.map((s) => ({ connected: !!s.ws, name: s.name }));
}

function handleHello(ws, m) {
  if (m.type === 'host') {
    let room = m.code ? rooms.get(String(m.code).toUpperCase()) : null;
    if (room) {
      if (room.host && room.host !== ws) { room.host.role = null; room.host.room = null; room.host.close(); }
      if (room.cleanup) { clearTimeout(room.cleanup); room.cleanup = null; }
    } else {
      room = {
        code: newCode(),
        host: null,
        slots: [{ ws: null, token: null, name: '' }], // one human player; the computer is player 2 on the host screen
        cleanup: null
      };
      rooms.set(room.code, room);
    }
    room.host = ws;
    ws.role = 'host';
    ws.room = room;
    send(ws, { type: 'room', code: room.code, players: playersOf(room) });
    room.slots.forEach((s) => send(s.ws, { type: 'hostback' }));
    return;
  }

  if (m.type === 'join') {
    const code = String(m.code || '').toUpperCase().trim();
    const room = rooms.get(code);
    if (!room) return send(ws, { type: 'error', fatal: true, message: 'No room with that code' });
    if (!room.host) return send(ws, { type: 'error', fatal: true, message: 'The host screen is offline' });
    const token = String(m.token || '').slice(0, 64);
    let idx = token ? room.slots.findIndex((s) => s.token === token) : -1;
    if (idx < 0) idx = room.slots.findIndex((s) => !s.ws);
    if (idx < 0) return send(ws, { type: 'error', fatal: true, message: 'The room is full' });
    const slot = room.slots[idx];
    if (slot.ws && slot.ws !== ws) {
      const old = slot.ws;
      old.role = null;
      old.room = null;
      send(old, { type: 'error', fatal: true, message: 'Joined from another device' });
      old.close();
    }
    slot.ws = ws;
    slot.token = token || 't' + Math.random().toString(36).slice(2);
    slot.name = String(m.name || 'Player ' + (idx + 1)).slice(0, 16);
    ws.role = 'player';
    ws.room = room;
    ws.slot = idx;
    send(ws, { type: 'joined', player: idx, name: slot.name });
    send(room.host, { type: 'player', player: idx, connected: true, name: slot.name });
  }
}

function handleHost(ws, m) {
  const room = ws.room;
  if (m.type === 'to' && room.slots[m.player]) send(room.slots[m.player].ws, m.msg);
  else if (m.type === 'toAll') room.slots.forEach((s) => send(s.ws, m.msg));
}

function handlePlayer(ws, m) {
  const room = ws.room;
  if (m.type === 'swing') {
    const power = Math.max(0, Math.min(1, +m.power || 0));
    const aim = Math.max(-1, Math.min(1, +m.aim || 0));
    send(room.host, { type: 'swing', player: ws.slot, power, aim, src: m.src === 'touch' ? 'touch' : 'motion' });
  } else if (m.type === 'ping') {
    send(ws, { type: 'pong', t: m.t });
  }
}

function handleClose(ws) {
  const room = ws.room;
  if (!room) return;
  if (ws.role === 'host' && room.host === ws) {
    room.host = null;
    room.slots.forEach((s) => send(s.ws, { type: 'hostgone' }));
    room.cleanup = setTimeout(() => rooms.delete(room.code), 120000);
  } else if (ws.role === 'player' && room.slots[ws.slot] && room.slots[ws.slot].ws === ws) {
    room.slots[ws.slot].ws = null;
    send(room.host, { type: 'player', player: ws.slot, connected: false, name: room.slots[ws.slot].name });
  }
}

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.role = null;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.type !== 'string') return;
    if (ws.role === null) handleHello(ws, m);
    else if (ws.role === 'host') handleHost(ws, m);
    else if (ws.role === 'player') handlePlayer(ws, m);
  });
  ws.on('close', () => handleClose(ws));
  ws.on('error', () => {});
});

// Drop connections that went silent (a phone that fell asleep, say).
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, 15000).unref();

// ---------------------------------------------------------------- start

function listen(server, port, label) {
  server.on('error', (e) => {
    console.error(label + ' server could not start on port ' + port + ': ' + e.message);
    process.exit(1);
  });
  server.on('upgrade', (req, socket, head) => {
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });
  server.listen(port, '0.0.0.0');
}

(async () => {
  const ips = lanAddresses();
  const cert = await loadCert(ips);
  info.ips = ips;
  info.httpsPort = cert ? HTTPS_PORT : null;

  listen(http.createServer(handler), HTTP_PORT, 'HTTP');
  if (cert) listen(https.createServer(cert, handler), HTTPS_PORT, 'HTTPS');

  console.log('\nPhone Pong is running.\n');
  console.log('  Host screen (TV / laptop):  http://localhost:' + HTTP_PORT);
  if (cert && ips.length) console.log('  Phones (scan the QR code):  https://' + ips[0] + ':' + HTTPS_PORT + '/play');
  else if (ips.length) console.log('  Phones:                     http://' + ips[0] + ':' + HTTP_PORT + '/play  (no HTTPS: swipe pad only)');
  console.log('\n  Phones must be on the same Wi-Fi as this computer.');
  if (cert) console.log('  First visit on a phone shows a certificate warning: tap Advanced, then Proceed.');
  console.log('');
})();
