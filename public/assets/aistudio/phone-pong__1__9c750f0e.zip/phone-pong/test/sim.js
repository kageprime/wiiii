'use strict';
// Headless check of the game rules: two bots play full matches, then we assert on the results.
// Run with: npm run sim
const assert = require('assert');
const PongGame = require('../public/game.js');

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function playMatches(seed, matches, skills) {
  const rng = mulberry32(seed);
  const log = { points: [], overs: [], hits: 0, bounces: 0, whiffs: 0, reasons: {}, maxRally: 0, servers: [] };
  const game = PongGame.createGame({
    rng,
    onEvent(name, d) {
      if (name === 'hit') log.hits++;
      if (name === 'bounce') log.bounces++;
      if (name === 'whiff') log.whiffs++;
      if (name === 'serve') log.servers.push(d.server);
      if (name === 'point') {
        log.points.push(d);
        log.reasons[d.reason] = (log.reasons[d.reason] || 0) + 1;
        log.maxRally = Math.max(log.maxRally, d.rally);
      }
      if (name === 'over') log.overs.push(d);
    }
  });
  const bots = [PongGame.createBot(game, 0, { rng, skill: skills[0] }), PongGame.createBot(game, 1, { rng, skill: skills[1] })];
  game.setConnected(0, true);
  game.setConnected(1, true);
  const dt = 1 / 60;
  let t = 0;
  while (log.overs.length < matches && t < 60 * 60 * 3) { // 3 simulated hours at most
    bots.forEach((b) => b.update(dt));
    game.update(dt);
    t += dt;
  }
  return { game, log, t };
}

// 1. Full matches finish with a legal score.
{
  const { log, t } = playMatches(1, 20, [0.85, 0.85]);
  assert.strictEqual(log.overs.length, 20, 'all 20 matches should finish (took ' + Math.round(t) + 's simulated)');
  for (const o of log.overs) {
    const [a, b] = o.score;
    assert(Math.max(a, b) >= 7, 'winner has at least 7: ' + o.score);
    assert(Math.abs(a - b) >= 2, 'winner is 2 clear: ' + o.score);
    assert.strictEqual(o.winner, a > b ? 0 : 1, 'winner matches the score');
  }
  assert(log.maxRally >= 4, 'bots should manage a real rally, longest was ' + log.maxRally);
  assert(log.hits > log.points.length, 'more hits than points means rallies happen');
  assert(log.bounces > 0, 'ball bounces');
  const known = new Set(['net', 'out', 'short', 'missed']);
  for (const r of Object.keys(log.reasons)) assert(known.has(r), 'unknown point reason ' + r);
  console.log('ok  matches finish with legal scores;', log.points.length, 'points, longest rally', log.maxRally, 'reasons', JSON.stringify(log.reasons));
}

// 2. Serve alternates every two points.
{
  const { log } = playMatches(7, 3, [0.8, 0.8]);
  // Walk the first match: server for point n (0-based) is (first + floor(n/2)) % 2 until deuce, then it still alternates each point.
  const first = log.servers[0];
  const n = log.overs[0].score[0] + log.overs[0].score[1];
  for (let i = 0; i < Math.min(n, 12); i++) {
    assert.strictEqual(log.servers[i], (first + Math.floor(i / 2)) % 2, 'serve rotation at point ' + i);
  }
  console.log('ok  serve rotates every two points');
}

// 3. The better bot wins more.
{
  const { log } = playMatches(42, 60, [0.95, 0.6]);
  const wins0 = log.overs.filter((o) => o.winner === 0).length;
  assert(wins0 > 40, 'skilled bot should win most matches, won ' + wins0 + ' of 60');
  console.log('ok  skill matters: strong bot won', wins0, 'of 60');
}

// 4. Rules enforced on human swings.
{
  const rng = mulberry32(3);
  const events = [];
  const game = PongGame.createGame({ rng, onEvent: (n, d) => events.push([n, d]) });
  const S = game.state;
  assert.strictEqual(S.phase, 'waiting');
  assert.strictEqual(game.swing(0, 0.5, 0).ok, false, 'no swinging before both players are in');
  game.setConnected(0, true);
  assert.strictEqual(S.phase, 'waiting', 'one player is not enough');
  game.setConnected(1, true);
  assert.strictEqual(S.phase, 'serve');
  const server = S.server;
  assert.strictEqual(game.swing(1 - server, 0.5, 0).ok, false, 'receiver cannot serve');
  assert.strictEqual(game.swing(server, 0.5, 0).ok, true, 'server can serve');
  assert.strictEqual(S.phase, 'rally');
  assert.strictEqual(game.swing(server, 0.5, 0).ok, false, 'cannot hit your own ball');
  assert.strictEqual(game.swing(1 - server, 0.5, 0).reason, 'too early', 'cannot hit before the bounce');

  // A phone dropping out pauses the match and keeps the score.
  S.score = [3, 2];
  game.setConnected(1, false);
  assert.strictEqual(S.phase, 'waiting');
  assert.deepStrictEqual(S.score, [3, 2], 'score survives a disconnect');
  game.setConnected(1, true);
  assert.strictEqual(S.phase, 'serve', 'resumes at a serve, not a new match');
  assert.deepStrictEqual(S.score, [3, 2]);
  console.log('ok  swing rules and reconnect behave');
}

// 5. Over-powered swings go long, soft swings land short or in the net: the power range is usable.
{
  const outcomes = { soft: {}, mid: {}, hard: {} };
  const powers = { soft: 0.0, mid: 0.5, hard: 1.0 };
  for (const [label, power] of Object.entries(powers)) {
    for (let i = 0; i < 200; i++) {
      const rng = mulberry32(1000 + i);
      let reason = null;
      const game = PongGame.createGame({ rng, onEvent: (n, d) => { if (n === 'point') reason = reason || d.reason; } });
      game.setConnected(0, true);
      game.setConnected(1, true);
      game.swing(game.state.server, power, 0);
      for (let k = 0; k < 60 * 30 && !reason; k++) game.update(1 / 60);
      outcomes[label][reason] = (outcomes[label][reason] || 0) + 1;
    }
  }
  console.log('    serve outcomes by power:', JSON.stringify(outcomes));
  assert((outcomes.mid.missed || 0) > 150, 'a medium serve should usually be a legal one the receiver cannot return');
  assert(!outcomes.mid.out, 'a medium serve should not go out');
  assert((outcomes.hard.out || 0) > 100, 'a full-power serve should usually go long');
  assert(!outcomes.soft.out && !outcomes.soft.net, 'a feather-light serve is a legal drop shot, not a fault');
  console.log('ok  power range behaves');
}

// 6. Badly timed returns can fault: net, short and out all happen, but a well-timed return is clean.
{
  function returnOutcome(seed, uOffset) {
    const rng = mulberry32(seed);
    let reason = null;
    const game = PongGame.createGame({ rng, onEvent: (n, d) => { if (n === 'point') reason = reason || d.reason; } });
    game.setConnected(0, true);
    game.setConnected(1, true);
    const S = game.state;
    const receiver = 1 - S.server;
    game.swing(S.server, 0.5, 0);
    let guard = 0;
    while (S.ball.bounces < 1 && !reason && guard++ < 60 * 10) game.update(1 / 60);
    if (reason) return 'serve-' + reason;
    S.ball.x = receiver === 0 ? uOffset : 1 - uOffset; // uOffset = distance in front of the receiver's end line
    const res = game.swing(receiver, 0.5, 0);
    if (!res.ok) return 'whiff-' + res.reason;
    for (let k = 0; k < 60 * 30 && !reason; k++) game.update(1 / 60);
    return reason;
  }
  const tally = (u) => {
    const t = {};
    for (let i = 0; i < 400; i++) { const r = returnOutcome(5000 + i, u); t[r] = (t[r] || 0) + 1; }
    return t;
  };
  const sloppy = tally(0.29);
  const clean = tally(0.0);
  console.log('    sloppy returns:', JSON.stringify(sloppy));
  console.log('    clean returns: ', JSON.stringify(clean));
  const faults = (t) => (t.net || 0) + (t.short || 0) + (t.out || 0);
  assert(faults(sloppy) > 80, 'sloppy timing should fault regularly, got ' + faults(sloppy) + ' of 400');
  assert((sloppy.net || 0) > 0, 'sloppy returns can find the net');
  assert(faults(clean) < 10, 'a perfectly timed return should almost never fault, got ' + faults(clean) + ' of 400');
  assert(faults(sloppy) > faults(clean) * 5, 'timing must matter');
  console.log('ok  timing matters: sloppy returns fault', faults(sloppy), 'times vs', faults(clean), 'for clean ones');
}

console.log('\nall simulation checks passed');
